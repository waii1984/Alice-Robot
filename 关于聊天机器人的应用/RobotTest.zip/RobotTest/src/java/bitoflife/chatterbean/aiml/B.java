package bitoflife.chatterbean.aiml;


import org.xml.sax.Attributes;


import bitoflife.chatterbean.Match;


public class B extends TemplateElement
{
  /*
  Constructors
  */

  public B(Attributes attributes)
  {
  }

  public B(Object... children)
  {
    super(children);
  }

  /*
  Methods
  */

  public String process(Match match)
  {
    return "";
  }
}